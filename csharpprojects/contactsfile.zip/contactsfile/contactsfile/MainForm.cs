﻿/*
 * Created by SharpDevelop.
 * User: raman
 * Date: 22-05-2021
 * Time: 15:01
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace contactsfile
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void Button1Click(object sender, EventArgs e)
		{
			 FileStream fs=null;
            string name;
            string address;
            string mobileno;
            string email;
            string cstr;
            string filename="c:\\temp\\contactsharpdevelop.txt";
            name=textBox1.Text;
            address=textBox2.Text;
            mobileno=textBox3.Text;
            email=textBox4.Text;
           
            cstr=name + "," + address + "," + mobileno + "," + email;
            try
            {
                fs = new FileStream(filename, FileMode.Append);
                using (StreamWriter writer = new StreamWriter(fs))
                {
                    writer.WriteLine(cstr);

                }
                MessageBox.Show("Data Written");
            }
            finally
            {
                
            }
		}
		
		void Button2Click(object sender, EventArgs e)
		{
			string d="";
			string a="";
			FileStream fs;
			string filename="c:\\temp\\contactsharpdevelop.txt";
			 try
            {
                fs = new FileStream(filename, FileMode.Open);
                using (StreamReader reader = new StreamReader(fs))
                {
                	while(!reader.EndOfStream)
                	{
                	a=reader.ReadLine();
                	d=d+a+"\r\n";
                	}
             }
                textBox5.Text=d;
            }
            finally
            {
                
            }
		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ContactsSqlServer
{
    public partial class ModifyRecord : Form
    {
        public ModifyRecord()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string namestr = textBox1.Text;
            string addressstr = textBox2.Text;
            string mobilenostr = textBox3.Text;
            string emailstr = textBox4.Text;
            int rs = 0;

            SqlConnection con = new
           SqlConnection("Server=LAPTOP-G4T4EDUV\\SQLEXPRESS;Database=contacts;Trusted_Connection=True;");
            con.Open();
            using var cmd = new SqlCommand("update contacts set caddress='" + addressstr + "',cmobileno='" + mobilenostr + "',cemail='" + emailstr + "' where cname = '" + namestr + "'", con);
            rs = cmd.ExecuteNonQuery();
            if (rs > 0)
            {
                MessageBox.Show(rs + " Contacts Record Updated");
            }
            else
            {
                MessageBox.Show("Contact Record can't be Updated");

            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ContactsSqlServer
{
    public partial class DeleteRecord : Form
    {
        public DeleteRecord()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string cname = textBox1.Text;
            SqlConnection con = new SqlConnection("Server=LAPTOP-G4T4EDUV\\SQLEXPRESS;Database=contacts;Trusted_Connection=True;");
            SqlCommand cmd = con.CreateCommand();
            con.Open();
            cmd.CommandText = "delete from contacts where cname='" + cname + "'";
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            MessageBox.Show("Contact Record Deleted");
            con.Close();
        }
    }
}

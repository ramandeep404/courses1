﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ContactsSqlServer
{
    public partial class AddRecord : Form
    {
        public AddRecord()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connetionString;
            string namestr;
            string addressstr;
            string mobilenostr;
            string emailstr;
            namestr = textBox1.Text;
            addressstr = textBox2.Text;
            mobilenostr = textBox3.Text;
            emailstr = textBox4.Text;
            SqlConnection cnn;
            connetionString = "Server=LAPTOP-G4T4EDUV\\SQLEXPRESS;Database=contacts;Trusted_Connection=True;";
            cnn = new SqlConnection(connetionString);
            cnn.Open();
            SqlCommand cmd = new SqlCommand("insert into contacts values('" + namestr + "','" + addressstr + "','" + mobilenostr + "','" + emailstr + "')", cnn);
            int rs;
            rs = cmd.ExecuteNonQuery();
            if (rs > 0)
            {
                MessageBox.Show("Record Inserted");
            }
            else
            {
                MessageBox.Show("Record Can't be Inserted");
            }
            cnn.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContactsSqlServer
{
    public partial class SearchRecord : Form
    {
        public SearchRecord()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string cnamestr = textBox1.Text;
            SqlConnection con = new SqlConnection("Server=LAPTOP-G4T4EDUV\\SQLEXPRESS;Database=contacts;Trusted_Connection=True;");
            con.Open();
            string q = "SELECT * FROM contacts WHERE cname LIKE '%" + cnamestr + "%'";
            using SqlDataAdapter a = new SqlDataAdapter(q, con);
            using DataTable t = new DataTable();
            a.Fill(t);
            dataGridView1.DataSource = t;
        }
    }
}

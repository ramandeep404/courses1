﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace ContactsOracleWinForm
{
    public partial class ModifyRecord : Form
    {
        public ModifyRecord()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string namestr = textBox1.Text;
            string addressstr = textBox2.Text;
            string mobilenostr = textBox3.Text;
            string emailstr = textBox4.Text;
            int rs = 0;
            string oradb = "Data Source=(DESCRIPTION =" + "(ADDRESS = (PROTOCOL = TCP)(HOST =localhost)(PORT = 1521))" + "(CONNECT_DATA =" + "(SERVER = DEDICATED)" + "(SERVICE_NAME = XE)));" + "User Id=system;Password=abcdef;";
            OracleConnection conn = new OracleConnection(oradb);
            conn.Open();
            using var cmd = new OracleCommand("update contacts set caddress='" + addressstr + "',cmobileno='" + mobilenostr + "',cemail='" + emailstr + "' where cname = '" + namestr + "'", conn);
           
            rs = cmd.ExecuteNonQuery();
            if (rs > 0)
            {
                MessageBox.Show(rs + " Contacts Record Updated");
            }
            else
            {
                MessageBox.Show("Contact Record can't be Updated");
            }
        }
    }
}

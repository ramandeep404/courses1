﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContactsOracleWinForm
{
    public partial class AddRecord : Form
    {
        public AddRecord()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string oradb = "Data Source=(DESCRIPTION =" + "(ADDRESS = (PROTOCOL = TCP)(HOST =localhost)(PORT = 1521))" + "(CONNECT_DATA =" + "(SERVER = DEDICATED)" + "(SERVICE_NAME = XE)));" + "User Id=system;Password=abcdef;";
            string namestr = textBox1.Text;
            string addressstr = textBox2.Text;
            string mobilenostr = textBox3.Text;
            string emailstr = textBox4.Text;
            OracleConnection conn = new OracleConnection(oradb);
            conn.Open();
            OracleCommand cmd = new OracleCommand("insert into contacts values('" + namestr + "','" + addressstr + "','" + mobilenostr + "','" + emailstr + "')",conn);
            int rs;
            rs = cmd.ExecuteNonQuery();
            if (rs > 0)
            {
                MessageBox.Show("Record Inserted");
            }
            else
            {
                MessageBox.Show("Record Can't be Inserted");
            }
            conn.Close();


        }
    }
}

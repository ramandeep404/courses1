﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContactsOracleWinForm
{
    public partial class SearchRecord : Form
    {
        public SearchRecord()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string cnamestr = textBox1.Text;
            string oradb = "Data Source=(DESCRIPTION =" + "(ADDRESS = (PROTOCOL = TCP)(HOST =localhost)(PORT = 1521))" + "(CONNECT_DATA =" + "(SERVER = DEDICATED)" + "(SERVICE_NAME = XE)));" + "User Id=system;Password=abcdef;";
            OracleConnection conn = new OracleConnection(oradb);
            conn.Open();
            string q = "SELECT * FROM contacts WHERE cname LIKE '%" + cnamestr + "%'";
            using OracleDataAdapter a = new OracleDataAdapter(q, conn);
            using DataTable t = new DataTable();
            a.Fill(t);
            dataGridView1.DataSource = t;
        }
    }
}

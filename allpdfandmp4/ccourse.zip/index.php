<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
       start from program 10 structures 
        <?php
        // put your code here
        ?>
    </body>
</html>

<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        Course Index - Select a Course
        <br>
        <form action="course.php" method="post" name="selectcourse">
            <input type="radio" value="cpp" name="index" >C++ Course
            <br>
            <input type="radio" value="c" name="index">C Course
            <br>
            <input type="radio" value="php" name="index">PHP Course
            <br>
            <input type="radio" value="java" name="index">Java Course
            <br>
             <input type="radio" value="sql" name="index">SQL Course
            <br>
            <input type="radio" value="html" name="index">HTML Course
            <br>
            <br>
            <input type="submit" value="Select a Course">
        </form>
    </body>
</html>

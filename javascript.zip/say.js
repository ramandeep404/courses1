export function sayHi(user) {
    return `Hello, ${user}!`;
  }
import * as say from './say.js';

say.sayHi('John');
say.sayBye('John');
import {sayHi, sayBye} from './say1.js';

sayHi('John'); // Hello, John!
sayBye('John'); // Bye, John!
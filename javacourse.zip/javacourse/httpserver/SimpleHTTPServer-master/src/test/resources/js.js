function toto(){
  var a="toto";
  alert(a);
}
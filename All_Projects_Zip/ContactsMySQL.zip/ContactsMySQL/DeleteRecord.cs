﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ContactsMySQL
{
    public partial class DeleteRecord : Form
    {
        public DeleteRecord()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string namestr = textBox1.Text;
            int rs = 0;
            string constr = "Server=localhost;User ID=root;Password=;Database=contacts";
            using var connection = new MySqlConnection(constr);
            connection.Open();
            using var mysqlcmd = new MySqlCommand("delete from contacts where cname = '" + namestr + "'", connection);
            rs = mysqlcmd.ExecuteNonQuery();
            if (rs > 0)
            {
                MessageBox.Show(rs + " Contacts Record Deleted");
            }
            else
            {
                MessageBox.Show("Contact Record Not Deleted");
            }
        }
    }
}


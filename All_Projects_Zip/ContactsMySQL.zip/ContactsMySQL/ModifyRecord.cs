﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContactsMySQL
{
    public partial class ModifyRecord : Form
    {
        public ModifyRecord()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string namestr = textBox1.Text;
            string addressstr = textBox2.Text;
            string mobilestr = textBox3.Text;
            string emailstr=textBox4.Text;
            int rs = 0;
            string constr = "Server=localhost;User ID=root;Password=;Database=contacts";
            using var connection = new MySqlConnection(constr);
            connection.Open();
            using var mysqlcmd = new MySqlCommand("update contacts set caddress='" + addressstr + "',cmobileno='"+mobilestr + "',cemail='"+emailstr + "' where cname='"+namestr+"'", connection);
            rs = mysqlcmd.ExecuteNonQuery();
            if (rs > 0)
            {
                MessageBox.Show("Record Modified");
            }
            else
            {
                MessageBox.Show("Record Not Modified");
            }
        }
    }
    }


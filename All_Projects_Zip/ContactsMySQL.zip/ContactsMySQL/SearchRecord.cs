﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContactsMySQL
{
    public partial class SearchRecord : Form
    {
        public SearchRecord()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string namestr = textBox1.Text;
            string constr = "Server=localhost;User ID=root;Password=;Database=contacts";
            using var connection = new MySqlConnection(constr);
            connection.Open();
            using MySqlDataAdapter a = new MySqlDataAdapter("SELECT * FROM contacts where cname like '%" + namestr + "%'", connection);

            using DataTable t = new DataTable();
            a.Fill(t);
            dataGridView1.DataSource = t;
        }
    }
}

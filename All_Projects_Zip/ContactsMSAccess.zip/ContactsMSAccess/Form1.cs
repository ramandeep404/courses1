namespace ContactsMSAccess
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddRecord a = new AddRecord();
            a.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ModifyRecord a = new ModifyRecord();
            a.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DeleteRecord a = new DeleteRecord();
            a.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SearchRecord a = new SearchRecord();
            a.Show();
        }
    }
}
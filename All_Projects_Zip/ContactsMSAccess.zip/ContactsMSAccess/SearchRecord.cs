﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContactsMSAccess
{
    public partial class SearchRecord : Form
    {
        public SearchRecord()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string cnamestr = textBox1.Text;
            OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=contacts.accdb");
            con.Open();
            string q = "SELECT * FROM contacts WHERE cname LIKE '%" + cnamestr + "%'";
            using OleDbDataAdapter a = new OleDbDataAdapter(q, con);
            using DataTable t = new DataTable();
            a.Fill(t);
            dataGridView1.DataSource = t;

        }
    }
}
